
<?php

include 'includes/header.php'; 
include 'main.php'; 
include 'classes/class.city.php';
//include 'classes/class.population.php';
$city=new City($db);
//$population=new Population($db);

$val='';$result='';$list='';$field='';$valid='';$listCity='';
/*$countrylist=$country->getCountryList();
$citylist=$city->getCityList();
$agelist=$age->getAgeList();
$populationlist=$population->getPopulationLists();
$fields=$population->getPopulationFields();
*/

$q=$_GET['q'];
$result=$city->getCityCountryListById($q);

echo '<script type="text/javascript">alert('.$q.');</script>';
echo '<script type="text/javascript">alert('.$result.');</script>';
$field="<option value='-1'>Select City</option>";
while($row=$result->fetch_assoc())
{
    $field .='<option value="'.$row['cityId'].'">'.$row['cityname'].'</option>';
}
  echo $field;

?>
