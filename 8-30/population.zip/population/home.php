<?php 
session_start();
include 'includes/header.php'; 
include 'main.php'; 
$error_message='';
?>

<div style="border:1px solid grey; height:auto; width:60%;">
<?php    
include_once 'includes/menu.php'; 
if(isset($_SESSION['user']))
    {
    echo 'Welcome :'.$_SESSION['user'];
    echo "<a href='logout.php'> Logout </a>";
    }
?>
<hr />
<fieldset>
    <legend> Filter Options </legend>
    <br />
    <form name="frmfilter" action="<?php htmlspecialchars($_SERVER['PHP_SELF']); ?> " method="post">
        <div style="width:100%;">
        <div style="width:30%; float:left;">
        <label for="country">Country</label>
        <select id="country" name="country">
            <option value="-1">ALL Countries</option>
            <option value="1">Countries</option>
        </select>
        </div>
        <div style="width:30%; float:left;">
        <label for="city">City </label>
        <select id="city" name="city">
            <option value="-1">Select City</option>
            <option value="1">city</option>
        </select>
        </div>
         <div style="width:30%; float:left;">
        <label for="age">Age </label>
        <select id="age" name="age">
            <option value="-1">Select AgeGroup</option>
            <option value="1">age</option>
        </select>
        </div>
        <div>
        <input type="submit" value="Login" />       
        </div>
        </div>
    </form>   
</fieldset>
<fieldset>
    <legend> Filter Values </legend>
    <br />
</fieldset>
<fieldset>
    <legend> Database Records </legend>
    
    <br />
</fieldset>
</div>

<?php include 'includes/footer.php'; ?>