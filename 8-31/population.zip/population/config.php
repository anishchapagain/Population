<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_DATA','population');
define('H_TAG','Application Population Census');
define('F_TAG','Copyright: application population census');
define('T_TAG','Population Census');

?>