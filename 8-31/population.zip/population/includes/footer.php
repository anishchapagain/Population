<p><small><?php //echo F_TAG; ?></small></p>
</div>
    </body>
</html>
