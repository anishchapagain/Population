<?php

/* 
 * Menu.php
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<a href="home.php">Home&nbsp;&nbsp;|</a>
<a href="country.php">Country&nbsp;&nbsp;|</a>
<a href="city.php">City&nbsp;&nbsp;|</a>
<a href="age.php">Age&nbsp;&nbsp;|</a>
<a href="population_ajax.php">Population</a>
